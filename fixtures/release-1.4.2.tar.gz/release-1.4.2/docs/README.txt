Example release 1.4.2
This is a sample release artifact used by the release-signing harness.
It is a real tarball with real files, built deterministically.
