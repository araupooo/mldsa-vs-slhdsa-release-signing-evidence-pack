/* example release 1.4.2 — dummy source file, part of the signed artifact */
#include <stdio.h>
int main(void) { printf("example release 1.4.2\n"); return 0; }
