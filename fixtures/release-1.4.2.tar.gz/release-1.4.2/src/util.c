/* example release 1.4.2 — dummy utility source */
int util_add(int a, int b) { return a + b; }
